const socket = io();

// --- Translations ---
const translations = {
  en: {
    title: "Smart Greenhouse Dashboard",
    nav: {
      brand: "Smart Greenhouse",
      home: "Home",
      controls: "Manual Control",
      about: "About",
      contact: "Contact"
    },
    dashboard: {
      overview: "Dashboard Overview",
      description: "Real-time monitoring of greenhouse environmental parameters",
      temperature: "Temperature",
      humidity: "Humidity",
      light: "Light Intensity",
      soil: "Soil Moisture"
    },
    status: {
      normal: "Normal"
    }
  },
  am: {
    title: "የስማርት ግሪንሃውስ ዳሽቦርድ",
    nav: {
      brand: "ስማርት ግሪንሃውስ",
      home: "መነሻ",
      controls: "በእጅ መቆጣጠሪያ",
      about: "ስለ",
      contact: "እንኳን ያገኙናል"
    },
    dashboard: {
      overview: "የዳሽቦርድ አጠቃላይ እይታ",
      description: "የግሪንሃውስ አካባቢ መለኪያዎች በተግባር ጊዜ ማሳያ",
      temperature: "የሙቀት መጠን",
      humidity: "እርጥበት",
      light: "የብርሃን ጥሩነት",
      soil: "የእርሻ ለምነት"
    },
    status: {
      normal: "ተለምዷል"
    }
  },
  ti: {
    title: "የስማርት ግሪንሃውስ ዳሽቦርድ",
    nav: {
      brand: "ስማርት ግሪንሃውስ",
      home: "መነሻ",
      controls: "በእጅ መቆጣጠሪያ",
      about: "ስለ",
      contact: "እንኳን ያገኙናል"
    },
    dashboard: {
      overview: "የዳሽቦርድ አጠቃላይ እይታ",
      description: "የግሪንሃውስ አካባቢ መለኪያዎች በተግባር ጊዜ ማሳያ",
      temperature: "የሙቀት መጠን",
      humidity: "እርጥበት",
      light: "የብርሃን ጥሩነት",
      soil: "የእርሻ ለምነት"
    },
    status: {
      normal: "ተለምዷል"
    }
  }
};

// --- Current Language ---
let currentLanguage = localStorage.getItem('language') || 'en';

// --- Thresholds ---
const TEMP_MAX = 30;   // °C
const HUM_MIN  = 40;   // %
const HUM_MAX  = 70;   // %
const SOIL_MIN = 300;  // analog value dry
const LIGHT_MIN = 150; // analog value low light

// --- Placeholder data ---
const labels = Array.from({length:20}, (_,i)=>`-${20-i}s`);
let tempData = 25;
let humData = 50;
let lightData = 300;
const soilData = Array(20).fill(400);

// --- Chart creation ---
function createChart(id, label, dataArray, colorFunc, yMin=0, yMax=100, animate=true, type='line'){
  const isBar = type === 'bar';

  return new Chart(document.getElementById(id), {
    type: type,
    data: {
      labels: isBar ? [label] : labels,
      datasets:[{
        label: label,
        data: isBar ? [dataArray] : dataArray,
        borderWidth: 3,
        borderColor: colorFunc(dataArray),
        backgroundColor: colorFunc(dataArray),
        fill:false,
        tension: isBar ? 0 : 0.4,   // CURVE
        pointRadius: isBar ? 0 : 3
      }]
    },
    options:{
      responsive:true,
      animation: animate ? { duration: 800 } : false,
      scales:{
        x:{
          title:{ display:true, text:"Time" }
        },
        y:{
          min:yMin,
          max:yMax,
          title:{ display:true, text:label }
        }
      }
    }
  });
}

// --- Color functions ---
const tempColor = v => v > TEMP_MAX ? 'red' : '#f44336';
const humColor  = v => (v<HUM_MIN || v>HUM_MAX) ? '#ff5722' : '#2196f3';
const soilColor = v => v<SOIL_MIN ? 'brown' : '#795548';
const lightColor= v => v<LIGHT_MIN ? '#ffc107' : '#ff9800';

// --- Create charts ---
const tempChart = createChart("tempChart","Temperature (°C)",tempData,tempColor,0,50,true,'bar');
const humChart  = createChart("humChart","Humidity (%)",humData,humColor,0,100,true,'bar');
const lightChart= createChart("lightChart","Light Intensity",lightData,lightColor,0,1023,true,'bar');
const soilChart = createChart("soilChart","Soil Moisture",soilData,soilColor,0,1023,false,'line');

// --- Motion alert element ---
const motionText = document.getElementById("motionText");

// --- Initialize displays ---
updateDisplays();

// --- Live simulation (remove when using real sensors) ---
let time = 0;
setInterval(() => {
  time += 0.1;
  tempData  = 25 + 5 * Math.sin(time);
  humData   = 50 + 20 * Math.sin(time * 0.8);
  lightData = 300 + 200 * Math.sin(time * 1.2);

  updateBars();
  updateDisplays();
  updateControlDisplays();
}, 2000);

// --- Update bars ---
function updateBars(){
  tempChart.data.datasets[0].data = [tempData];
  tempChart.data.datasets[0].backgroundColor = tempColor(tempData);
  tempChart.data.datasets[0].borderColor = tempColor(tempData);

  humChart.data.datasets[0].data = [humData];
  humChart.data.datasets[0].backgroundColor = humColor(humData);
  humChart.data.datasets[0].borderColor = humColor(humData);

  lightChart.data.datasets[0].data = [lightData];
  lightChart.data.datasets[0].backgroundColor = lightColor(lightData);
  lightChart.data.datasets[0].borderColor = lightColor(lightData);

  tempChart.update();
  humChart.update();
  lightChart.update();
}

// --- Update displayed values and statuses ---
function updateDisplays(){
  // Temperature
  document.getElementById("tempVal").innerText = tempData.toFixed(1);
  let tempStatus = tempData > TEMP_MAX ? "High" : tempData < 15 ? "Low" : "Normal";
  document.getElementById("tempStatus").innerText = tempStatus;
  let tempPercent = Math.max(0, Math.min(100, ((tempData - 15) / (35 - 15)) * 100));
  document.getElementById("tempRangeFill").style.width = tempPercent + "%";

  // Humidity
  document.getElementById("humVal").innerText = humData.toFixed(1);
  let humStatus = (humData < HUM_MIN || humData > HUM_MAX) ? "Abnormal" : "Normal";
  document.getElementById("humStatus").innerText = humStatus;
  let humPercent = Math.max(0, Math.min(100, ((humData - 20) / (80 - 20)) * 100));
  document.getElementById("humRangeFill").style.width = humPercent + "%";

  // Light
  document.getElementById("lightVal").innerText = Math.round(lightData);
  let lightStatus = lightData < LIGHT_MIN ? "Low" : "Normal";
  document.getElementById("lightStatus").innerText = lightStatus;
  let lightPercent = Math.max(0, Math.min(100, ((lightData - 100) / (800 - 100)) * 100));
  document.getElementById("lightRangeFill").style.width = lightPercent + "%";

  // Soil
  document.getElementById("soilVal").innerText = Math.round(soilData[soilData.length-1] || 0);
  let soilStatus = (soilData[soilData.length-1] || 0) < SOIL_MIN ? "Dry" : "Normal";
  document.getElementById("soilStatus").innerText = soilStatus;
  let soilPercent = Math.max(0, Math.min(100, (((soilData[soilData.length-1] || 0) - 200) / (600 - 200)) * 100));
  document.getElementById("soilRangeFill").style.width = soilPercent + "%";
}

// --- Update control panel displays ---
function updateControlDisplays(){
  // Current temperature
  document.getElementById("currentTemp").innerText = tempData.toFixed(1) + "°C";

  // Current soil moisture
  document.getElementById("currentSoil").innerText = Math.round(soilData[soilData.length-1] || 0);

  // Current light level
  document.getElementById("currentLight").innerText = Math.round(lightData) + " lux";
}

// --- Socket real data ---
socket.on("sensorData", data => {
  const t = new Date().toLocaleTimeString();
  labels.push(t);
  labels.shift();

  tempData  = data.temperature  ?? tempData;
  humData   = data.humidity   ?? humData;
  lightData = data.light?? lightData;

  soilData.push(data.soil ?? soilData[soilData.length-1]);
  soilData.shift();

  updateBars();
  updateDisplays();
  updateControlDisplays();

  soilChart.data.datasets[0].data = soilData;
  soilChart.data.datasets[0].borderColor =
      soilColor(soilData[soilData.length-1]);
  soilChart.update();

  // Motion
  if(data.motion){
    motionText.innerText = "🚨 MOTION DETECTED";
    motionText.classList.add("alert");
  } else {
    motionText.innerText = "No Motion";
    motionText.classList.remove("alert");
  }
});

// --- Device status updates ---
socket.on("deviceStatus", data => {
  if(data.fan !== undefined) {
    document.getElementById("fanStatusDisplay").innerText = data.fan;
    document.getElementById("fanStatusDisplay").className = "status-badge " + (data.fan === "ON" ? "ON" : "OFF");
  }
  if(data.pump !== undefined) {
    document.getElementById("pumpStatusDisplay").innerText = data.pump;
    document.getElementById("pumpStatusDisplay").className = "status-badge " + (data.pump === "ON" ? "ON" : "OFF");
  }
  if(data.light !== undefined) {
    document.getElementById("lightStatusDisplay").innerText = data.light;
    document.getElementById("lightStatusDisplay").className = "status-badge " + (data.light === "ON" ? "ON" : "OFF");
  }
});

// --- Manual controls ---
function sendControl(command){
  socket.emit("control", command);

  // Local immediate update for better responsiveness
  if(command === 'fan_on') {
    document.getElementById("fanStatusDisplay").innerText = "ON";
    document.getElementById("fanStatusDisplay").className = "status-badge ON";
  } else if(command === 'fan_off') {
    document.getElementById("fanStatusDisplay").innerText = "OFF";
    document.getElementById("fanStatusDisplay").className = "status-badge OFF";
  } else if(command === 'pump_on') {
    document.getElementById("pumpStatusDisplay").innerText = "ON";
    document.getElementById("pumpStatusDisplay").className = "status-badge ON";
  } else if(command === 'pump_off') {
    document.getElementById("pumpStatusDisplay").innerText = "OFF";
    document.getElementById("pumpStatusDisplay").className = "status-badge OFF";
  } else if(command === 'light_on') {
    document.getElementById("lightStatusDisplay").innerText = "ON";
    document.getElementById("lightStatusDisplay").className = "status-badge ON";
  } else if(command === 'light_off') {
    document.getElementById("lightStatusDisplay").innerText = "OFF";
    document.getElementById("lightStatusDisplay").className = "status-badge OFF";
  }
}

// --- Menu navigation ---
function showPage(pageId){
  // Hide all pages
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));

  // Show selected page
  const targetPage = document.getElementById(pageId + "-page");
  if(targetPage) targetPage.classList.add("active");

  // Update navigation
  document.querySelectorAll(".nav-link").forEach(link => link.classList.remove("active"));
  const activeLink = document.querySelector(`[data-page="${pageId}"]`);
  if(activeLink) activeLink.classList.add("active");
}

// --- Language switching function ---
function switchLanguage(lang) {
  currentLanguage = lang;
  localStorage.setItem('language', lang);

  // Update document language
  document.documentElement.lang = lang;

  // Update all elements with data-i18n attributes
  document.querySelectorAll('[data-i18n]').forEach(element => {
    const key = element.getAttribute('data-i18n');
    const keys = key.split('.');
    let value = translations[lang];

    // Navigate through nested object
    for (const k of keys) {
      value = value && value[k];
    }

    if (value) {
      element.textContent = value;
    }
  });

  // Update page title
  document.title = translations[lang].title;
}

// --- Initialize navigation ---
document.addEventListener('DOMContentLoaded', function(){
  // Set up language selector
  const languageSelect = document.getElementById('languageSelect');
  if (languageSelect) {
    languageSelect.value = currentLanguage;
    languageSelect.addEventListener('change', function() {
      switchLanguage(this.value);
    });
  }

  // Set up navigation
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function(e){
      e.preventDefault();
      const page = this.getAttribute('data-page');
      showPage(page);
    });
  });

  // Set up footer navigation
  document.querySelectorAll('.footer-links a').forEach(link => {
    link.addEventListener('click', function(e){
      e.preventDefault();
      const page = this.getAttribute('data-page');
      showPage(page);
    });
  });

  // Initialize language
  switchLanguage(currentLanguage);

  // Show home page by default
  showPage('home');

  // Initialize displays
  updateDisplays();
  updateControlDisplays();
});
