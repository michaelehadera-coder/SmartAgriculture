const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const { SerialPort } = require("serialport");
const { ReadlineParser } = require("@serialport/parser-readline");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// ================= SERIAL CONFIG =================
// CHANGE THIS TO YOUR ARDUINO PORT
const port = new SerialPort({
  path: "COM4",        // <-- CHANGE IF NEEDED
  baudRate: 9600,
  autoOpen: true
});

const parser = port.pipe(new ReadlineParser({ delimiter: "\n" }));

// Add serial port event listeners for debugging
port.on('open', () => {
  console.log("✅ Serial port opened successfully on COM4");
});

port.on('error', (err) => {
  console.log("❌ Serial port error:", err.message);
});

port.on('close', () => {
  console.log("🔌 Serial port closed");
});

// ================= DATA OBJECT =================
let sensorData = {
  temperature: 0,
  humidity: 0,
  light: 0,
  soil: 0,
  motion: false,
  fanStatus: "OFF",
  pumpStatus: "OFF",
  lightStatus: "OFF"
};

// ================= SERIAL READER =================
parser.on("data", line => {
  if (!line) return;

  line = line.toString().trim();
  console.log("RAW:", line);

  // TEMPERATURE
  if (line.startsWith("Temp:")) {
    let num = line.replace(/[^0-9.]/g, "");
    sensorData.temperature = parseFloat(num);
  }

  // HUMIDITY
  if (line.startsWith("Humidity:")) {
    let num = line.replace(/[^0-9.]/g, "");
    sensorData.humidity = parseFloat(num);
  }

  // LIGHT
  if (line.startsWith("Light:")) {
    let num = line.replace(/[^0-9]/g, "");
    sensorData.light = parseInt(num);
  }

  // SOIL
  if (line.startsWith("Soil Moisture:")) {
    let num = line.replace(/[^0-9]/g, "");
    sensorData.soil = parseInt(num);
  }

  // MOTION
  if (line.includes("Motion Detected")) {
    sensorData.motion = true;
  } else if (line.includes("No Motion")) {
    sensorData.motion = false;
  }

  // Device status feedback from Arduino
  if (line.includes("FAN: ON")) {
    sensorData.fanStatus = "ON";
  } else if (line.includes("FAN: OFF")) {
    sensorData.fanStatus = "OFF";
  } else if (line.includes("PUMP: ON")) {
    sensorData.pumpStatus = "ON";
  } else if (line.includes("PUMP: OFF")) {
    sensorData.pumpStatus = "OFF";
  } else if (line.includes("LIGHT: ON")) {
    sensorData.lightStatus = "ON";
  } else if (line.includes("LIGHT: OFF")) {
    sensorData.lightStatus = "OFF";
  }

  io.emit("sensorData", sensorData);
});

// ================= SOCKET.IO =================
io.on("connection", socket => {
  console.log("🌐 Dashboard connected");
  
  // Send current data to new client
  socket.emit("sensorData", sensorData);
  socket.emit("deviceStatus", {
    fan: sensorData.fanStatus,
    pump: sensorData.pumpStatus,
    light: sensorData.lightStatus
  });

  // Handle control events from frontend
  socket.on("control", (cmd) => {
    console.log("🎮 Control command received:", cmd);

    // Map frontend commands to Arduino commands
    switch(cmd) {
      case "fan_on":
        port.write("FAN_ON\n", (err) => {
          if (err) {
            console.log("❌ Error writing FAN_ON to serial port:", err.message);
          } else {
            console.log("✅ Successfully wrote FAN_ON to serial port");
            sensorData.fanStatus = "ON";
          }
        });
        break;
      case "fan_off":
        port.write("FAN_OFF\n", (err) => {
          if (err) {
            console.log("❌ Error writing FAN_OFF to serial port:", err.message);
          } else {
            console.log("✅ Successfully wrote FAN_OFF to serial port");
            sensorData.fanStatus = "OFF";
          }
        });
        break;
      case "pump_on":
        port.write("PUMP_ON\n", (err) => {
          if (err) {
            console.log("❌ Error writing PUMP_ON to serial port:", err.message);
          } else {
            console.log("✅ Successfully wrote PUMP_ON to serial port");
            sensorData.pumpStatus = "ON";
          }
        });
        break;
      case "pump_off":
        port.write("PUMP_OFF\n", (err) => {
          if (err) {
            console.log("❌ Error writing PUMP_OFF to serial port:", err.message);
          } else {
            console.log("✅ Successfully wrote PUMP_OFF to serial port");
            sensorData.pumpStatus = "OFF";
          }
        });
        break;
      case "light_on":
        port.write("LIGHT_ON\n", (err) => {
          if (err) {
            console.log("❌ Error writing LIGHT_ON to serial port:", err.message);
          } else {
            console.log("✅ Successfully wrote LIGHT_ON to serial port");
            sensorData.lightStatus = "ON";
          }
        });
        break;
      case "light_off":
        port.write("LIGHT_OFF\n", (err) => {
          if (err) {
            console.log("❌ Error writing LIGHT_OFF to serial port:", err.message);
          } else {
            console.log("✅ Successfully wrote LIGHT_OFF to serial port");
            sensorData.lightStatus = "OFF";
          }
        });
        break;
      default:
        console.log("⚠️ Unknown command:", cmd);
    }

    // Broadcast updated status to all clients
    io.emit("deviceStatus", {
      fan: sensorData.fanStatus,
      pump: sensorData.pumpStatus,
      light: sensorData.lightStatus
    });
  });

  // Backward compatibility with old event names
  socket.on("fan_on", () => {
    port.write("FAN_ON\n");
    sensorData.fanStatus = "ON";
    io.emit("deviceStatus", { fan: "ON", pump: sensorData.pumpStatus, light: sensorData.lightStatus });
  });
  
  socket.on("fan_off", () => {
    port.write("FAN_OFF\n");
    sensorData.fanStatus = "OFF";
    io.emit("deviceStatus", { fan: "OFF", pump: sensorData.pumpStatus, light: sensorData.lightStatus });
  });
  
  socket.on("pump_on", () => {
    port.write("PUMP_ON\n");
    sensorData.pumpStatus = "ON";
    io.emit("deviceStatus", { fan: sensorData.fanStatus, pump: "ON", light: sensorData.lightStatus });
  });
  
  socket.on("pump_off", () => {
    port.write("PUMP_OFF\n");
    sensorData.pumpStatus = "OFF";
    io.emit("deviceStatus", { fan: sensorData.fanStatus, pump: "OFF", light: sensorData.lightStatus });
  });
  
  socket.on("light_on", () => {
    port.write("LIGHT_ON\n");
    sensorData.lightStatus = "ON";
    io.emit("deviceStatus", { fan: sensorData.fanStatus, pump: sensorData.pumpStatus, light: "ON" });
  });
  
  socket.on("light_off", () => {
    port.write("LIGHT_OFF\n");
    sensorData.lightStatus = "OFF";
    io.emit("deviceStatus", { fan: sensorData.fanStatus, pump: sensorData.pumpStatus, light: "OFF" });
  });

  socket.on("disconnect", () => {
    console.log("🔌 Dashboard disconnected");
  });
});

// ================= STATIC FILES =================
app.use(express.static(path.join(__dirname, "public")));

// ================= START SERVER =================
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
  console.log(`📡 Waiting for serial connection on COM4...`);
});